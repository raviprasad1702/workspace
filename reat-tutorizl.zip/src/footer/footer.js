import React, { Component } from "react";

class RWDfooter extends Component {
  render() {
    return (
      <footer className="footer bg-white">
        <div className="container footer-cnt">
          <div className="row">
            <div className="footer-left col-md-9 col-sm-12">
              <div className="col-md-4 col-sm-12">
                <ul className="pl-0">
                  <li>
                    {" "}
                    <a href="#">About US</a>
                  </li>
                  <li>
                    <a href="#">Contact Us</a>
                  </li>
                  <li>
                    <a href="#">Customer Support</a>
                  </li>
                </ul>
              </div>

              <div className="col-md-4 colsm-12">
                <ul className="pl-0">
                  <li>
                    <a href="#">Subscribe </a>
                  </li>
                  <li>
                    <a href="#">Terms and Conditions </a>
                  </li>
                  <li>
                    <a href="#">Privacy Policy </a>
                  </li>
                </ul>
              </div>

              <div className=" t-font-18px col-md-4 col-sm-12">
                <p>
                  <a href="#">Subscribe </a>
                </p>
                <p>
                  <a href="#">Terms and Conditions </a>
                </p>
                <p>
                  <a href="#">Privacy Policy </a>
                </p>
              </div>
            </div>

            <div className="col-md-3 col-sm-12">
              <div className="footer-right col-md-12 col-sm-6 pr-0 pl-0">
                <p className="text-range t-font t-font-bold">
                  We support all these Payment Methods
                </p>
                <span className="icon icon-pay-methods"></span>
              </div>
            </div>
          </div>
        </div>
      </footer>
    );
  }
}

export default RWDfooter;
