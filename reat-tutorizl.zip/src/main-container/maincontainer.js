import React, { Component } from "react";

import Carousel from "../carousel/carousel";
import NewArrival from "../new-arrival/newArrival";
import Bestsales from "../best-sales/bestSales";
import UsetReviews from "../user-review/userReview";
import NewLetter from "../newsLetter/news-letter";

class Maincontainer extends Component {
  render() {
    return (
      <div>
        <Carousel />
        <NewArrival />
        <Bestsales />
        <UsetReviews />
        <NewLetter />
      </div>
    );
  }
}

export default Maincontainer;
