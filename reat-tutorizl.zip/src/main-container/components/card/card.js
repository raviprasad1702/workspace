import React, { Component } from "react";

class Card extends Component {
  cardData = {};
  constructor(props) {
    super();
    this.cardData = props.cardData;
  }
  render() {
    return (
      <div className="items bg-white">
        <img src={this.cardData.imagePath} alt={this.cardData.imageAtlText} />
        <h2 className="subhead1 dark-color">{this.cardData.title}</h2>
        <p className="para1">
          <i className={this.cardData.cartIconClass}>cart icon</i>
          <i className={this.cardData.favIconClass}>favarate icon</i>
        </p>

        <button className={this.cardData.notifyButton}>Notify Me</button>
      </div>
    );
  }
}

export default Card;
