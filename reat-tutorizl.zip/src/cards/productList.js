import React, { Component } from "react";
import imageurl from "../assets/images/mobile1.png";

class ProductList extends Component {
  prdList = [
    {
      imagePath: imageurl,
      imageAtlText: "Iphone",
      title: "Iphone",
      cartIconClass: "icon icon-cart",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    },
    {
      imagePath: imageurl,
      imageAtlText: "Moto G",
      title: "Moto G",
      cartIconClass: "icon icon-cart",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    },
    {
      imagePath: imageurl,
      imageAtlText: "Moto G",
      title: "Moto G",
      cartIconClass: "icon icon-cart ",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    },
    {
      imagePath: imageurl,
      imageAtlText: "Moto G",
      title: "Moto G",
      cartIconClass: "icon icon-cart ",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    },
    {
      imagePath: imageurl,
      imageAtlText: "Moto G",
      title: "Moto G",
      cartIconClass: "icon icon-cart ",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    },
    {
      imagePath: imageurl,
      imageAtlText: "Moto G",
      title: "Moto G",
      cartIconClass: "icon icon-cart ",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    },
    {
      imagePath: imageurl,
      imageAtlText: "Moto G",
      title: "Moto G",
      cartIconClass: "icon icon-cart ",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    },
    {
      imagePath: imageurl,
      imageAtlText: "Moto G",
      title: "Moto G",
      cartIconClass: "icon icon-cart ",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    },
    {
      imagePath: imageurl,
      imageAtlText: "Moto G",
      title: "Moto G",
      cartIconClass: "icon icon-cart ",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    },
    {
      imagePath: imageurl,
      imageAtlText: "Moto G",
      title: "Moto G",
      cartIconClass: "icon icon-cart ",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    },
    {
      imagePath: imageurl,
      imageAtlText: "Moto G",
      title: "Moto G",
      cartIconClass: "icon icon-cart ",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    },
    {
      imagePath: imageurl,
      imageAtlText: "Moto G",
      title: "Moto G",
      cartIconClass: "icon icon-cart ",
      favIconClass: "icon icon-faverate ",
      notifyButton: "notify-btn"
    }
  ];

  render() {
    const productListItems = this.prdList.map((prd, index) => {
      return (
        <div className="items bg-white" key={index}>
          <img src={prd.imagePath} alt={prd.imageAtlText} />
          <h2 className="subhead1 dark-color">{prd.title}</h2>
          <p className="para1">
            <i className={prd.cartIconClass}>cart icon</i>
            <i className={prd.favIconClass}>favarate icon</i>
          </p>

          <button className={prd.notifyButton}>Notify Me</button>
        </div>
      );
    });

    return <React.Fragment>{productListItems}</React.Fragment>;
  }
}

export default ProductList;
