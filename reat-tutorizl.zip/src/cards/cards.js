import React, { Component } from "react";
import ProductList from "./productList";
import $ from "jquery";

class RWDcards extends Component {
  render() {
    return (
      <div className="newArrival">
        <h1 className="recom-head prduct-title text-center text-uppercase mt-5 pt-5 heading-text text-uppercase">
          <span className="text-white">New</span> Arrivals
        </h1>
        <h2 className="text-white text-center">
          Mobile phones from the top brands are available ar the most
          comoetitive price
        </h2>

        <div className="itmesList">
          <div className="product-item">
            <div className="listItems">
              <ProductList />
            </div>
          </div>
        </div>

        <div className="text-center loadAll">
          <h3 className="bg-white">
            <a href="#" id="loadMore" className="bg-white el-display-block">
              Load All
            </a>
          </h3>
        </div>
      </div>
    );
  }
}

export default RWDcards;
