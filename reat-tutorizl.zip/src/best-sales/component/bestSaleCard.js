import React, { Component } from "react";

class BSPRD_cards extends Component {
  BSPRDdata = {};
  cardType = "";
  constructor(props) {
    super();
    this.BSPRDdata = props.BSPRDdata;
    this.cardType = props.cardType;
  }
  render() {
    const bestSales = (
      <React.Fragment>
        <div className="list-inline-item">
          <h4>{this.BSPRDdata.title}</h4>
          <div className="rating">
            <input
              type="radio"
              class="star"
              id="radio1"
              value="5"
              name="star"
            />
            <label class="radio1">★</label>
            <input
              type="radio"
              class="star"
              id="radio1"
              value="5"
              name="star"
            />
            <label class="radio1">★</label>
            <input
              type="radio"
              class="star"
              id="radio1"
              value="5"
              name="star"
            />
            <label class="radio1">★</label>
            <input
              type="radio"
              class="star"
              id="radio1"
              value="5"
              name="star"
            />
            <label class="radio1">★</label>
            <input
              type="radio"
              class="star"
              id="radio1"
              value="5"
              name="star"
            />
            <label class="radio1">★</label>
          </div>
        </div>
        <div className="addCart">
          <a href="#">
            <i className="icon icon-cart pull-left"></i> Add to cart
          </a>
        </div>
      </React.Fragment>
    );
    const userReview = (
      <div className="list-inline-item">
        <p>
          <a href="">
            Very good performance and good lokk and feel with stylish look{" "}
          </a>
        </p>
      </div>
    );
    return (
      <div className="items bg-white">
        <div>
          <img
            src={this.BSPRDdata.imagePath}
            alt={this.BSPRDdata.imageAltText}
          />
        </div>
        {this.cardType === "BestSales" ? bestSales : userReview}
      </div>
    );
  }
}

export default BSPRD_cards;
