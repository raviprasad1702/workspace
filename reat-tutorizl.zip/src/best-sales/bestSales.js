import React, { Component } from "react";
import BSPRD_cards from "./component/bestSaleCard";
import BSPRD_items from "../shared/bestSaleProducts";

class Bestsales extends Component {
  render() {
    return (
      <div className="best-sales">
        <h3 className="recom-head text-center prduct-title heading-text text-uppercase ">
          <span className="text-white">Best</span> Sales
        </h3>
        <p className="text-center text-white">
          Find the best sellers collections
        </p>

        <div className="bestSales">
          {BSPRD_items.slice(0, 3).map(BSPitems => {
            return <BSPRD_cards BSPRDdata={BSPitems} cardType="BestSales" />;
          })}
        </div>
      </div>
    );
  }
}

export default Bestsales;
