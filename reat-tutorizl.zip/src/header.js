import React, { Component } from "react";
import logoImage from "./assets/images/logo.png";

class RWDHeader extends Component {
  render() {
    return (
      <header>
        <div className="top-navar container-fluid">
          <div className="profile">
            <a href="#">
              <i className="icon icon-search"> </i>
            </a>
            <a href="#">
              <i className="icon icon-user"> </i>
            </a>
            <a href="#">
              <i className="icon icon-my-cart"> </i>
            </a>
          </div>
        </div>
        <nav className="container-fluid bg-white resp-navBar ">
          <div className="logo">
            <a className="navbar-brand company-text" href="#">
              <img src={logoImage} alt="Mobile shop logo" />
            </a>
          </div>
          <ul className="nav-list">
            <li className="nav-item active">
              <a href="index.html">Home</a>
            </li>
            <li>
              <a href="#">Mobiles</a>
            </li>
            <li>
              <a href="#">Hot Deals</a>
            </li>
            <li>
              <a href="#">About</a>
            </li>
            <li>
              <a href="#">Contact</a>
            </li>
          </ul>
        </nav>
      </header>
    );
  }
}

export default RWDHeader;
