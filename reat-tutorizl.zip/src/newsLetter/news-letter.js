import React, { Component } from "react";

class NewLetter extends Component {
  render() {
    return (
      <div className>
        <div className="news-letter bg-white">
          <div className="left">
            <p>
              <strong>
                <span className="text-uppercase text-range mr-3">
                  News Letter
                </span>
                Subscribe now to get all news and special offers
              </strong>
            </p>
          </div>

          <div className="news">
            <input type="email" name="" className="subscribe" />
            <input type="submit" name="submit" value="Subscribe" />
          </div>
        </div>
      </div>
    );
  }
}

export default NewLetter;
