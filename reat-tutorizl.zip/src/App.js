import React from "react";
import "./App.scss";
import RWDHeader from "./header";
import Carousel from "./carousel/carousel";
// import RWDcards from "./cards/cards";
import Maincontainer from "./main-container/maincontainer";
import Bestsales from "./best-sales/bestSales";
import RWDfooter from "./footer/footer";

function App() {
  return (
    <div className="App">
      <RWDHeader />
      <Maincontainer />
      <RWDfooter />
    </div>
  );
}

export default App;
