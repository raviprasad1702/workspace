import imageurl from "../assets/images/mobile1.png";

const PRDitems = [
  {
    imagePath: imageurl,
    imageAtlText: "Iphone",
    title: "Iphone",
    cartIconClass: "icon icon-cart",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  },
  {
    imagePath: imageurl,
    imageAtlText: "Moto G",
    title: "Moto G",
    cartIconClass: "icon icon-cart",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  },
  {
    imagePath: imageurl,
    imageAtlText: "Moto G",
    title: "Moto G",
    cartIconClass: "icon icon-cart ",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  },
  {
    imagePath: imageurl,
    imageAtlText: "Moto G",
    title: "Moto G",
    cartIconClass: "icon icon-cart ",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  },
  {
    imagePath: imageurl,
    imageAtlText: "Moto G",
    title: "Moto G",
    cartIconClass: "icon icon-cart ",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  },
  {
    imagePath: imageurl,
    imageAtlText: "Moto G",
    title: "Moto G",
    cartIconClass: "icon icon-cart ",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  },
  {
    imagePath: imageurl,
    imageAtlText: "Moto G",
    title: "Moto G",
    cartIconClass: "icon icon-cart ",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  },
  {
    imagePath: imageurl,
    imageAtlText: "Moto G",
    title: "Moto G",
    cartIconClass: "icon icon-cart ",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  },
  {
    imagePath: imageurl,
    imageAtlText: "Moto G",
    title: "Moto G",
    cartIconClass: "icon icon-cart ",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  },
  {
    imagePath: imageurl,
    imageAtlText: "Moto G",
    title: "Moto G",
    cartIconClass: "icon icon-cart ",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  },
  {
    imagePath: imageurl,
    imageAtlText: "Moto G",
    title: "Moto G",
    cartIconClass: "icon icon-cart ",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  },
  {
    imagePath: imageurl,
    imageAtlText: "Moto G",
    title: "Moto G",
    cartIconClass: "icon icon-cart ",
    favIconClass: "icon icon-faverate ",
    notifyButton: "notify-btn"
  }
];

export default PRDitems;
