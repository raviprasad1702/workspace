import imageUrl from "../assets/images/thumbnailmobile.png";

const BSPRD_items = [
  {
    imagePath: imageUrl,
    imageAltText: "iphone",
    title: "Iphone",
    cartIconClass: "icon icon-cart"
  },
  {
    imagePath: imageUrl,
    imageAltText: "iphone",
    title: "Iphone",
    cartIconClass: "icon icon-cart"
  },
  {
    imagePath: imageUrl,
    imageAltText: "iphone",
    title: "Iphone",
    cartIconClass: "icon icon-cart"
  }
];

export default BSPRD_items;
