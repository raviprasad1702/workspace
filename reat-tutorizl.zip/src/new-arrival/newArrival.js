import React, { Component } from "react";
import Card from "../main-container/components/card/card";
import PRDitems from "../shared/products";

class NewArrival extends Component {
  loadmore = () => { };
  state = {
    products: PRDitems
  }
  render() {
    return (
      <div className="newArrival">
        <h1 className="recom-head prduct-title text-center text-uppercase mt-5 pt-5 heading-text text-uppercase">
          <span className="text-white">New</span> Arrivals
        </h1>
        <h2 className="text-white text-center">
          Mobile phones from the top brands are available ar the most
          comoetitive price
        </h2>
        <div className="itmesList">
          <div className="product-item">
            {this.state.products.map(item => item.title)}
          </div>
        </div>
        <div className="text-center loadAll">
          <h3 className="bg-white">
            <button onClick={this.handelLoadMore} id="loadMore" className="bg-white el-display-block">
              Load All
            </button>
          </h3>
        </div>
      </div>
    );
  }
}

export default NewArrival;
