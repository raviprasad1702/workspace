import React, { Component } from "react";
import BSPRD_cards from "../best-sales/component/bestSaleCard";
import BSPRD_items from "../shared/bestSaleProducts";

class UsetReviews extends Component {
  state = {
    reviews: BSPRD_items
  }
  render() {
    const { reviews: RW } = this.state;
    return (
      <div className="user-review">
        <h3 className="recom-head text-center prduct-title heading-text text-uppercase ">
          <span className="text-white">User</span> Reviews
        </h3>
        <p className="text-center text-white">
          Find the best sellers collections
        </p>

        <div className="bestSales">
          {/* {BSPRD_items.slice(0, 3).map(BSPitems => {
            return <BSPRD_cards BSPRDdata={BSPitems} cardType="" />;
          })} */

            RW.map(review => <BSPRD_cards BSPRDdata={review} cardType="" />)}
        </div>
      </div>
    );
  }
}

export default UsetReviews;
