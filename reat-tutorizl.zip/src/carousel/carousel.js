import React, { Component } from "react";
import bgImage from "../assets/images/carosuel.png";
import $ from "jquery";
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";

class Carousel extends Component {
  render() {
    return (
      <OwlCarousel
        id="owl-demo"
        className="owl-carousel owl-theme carosuelSlider"
        loop
        items={1}
      >
        <div className="item">
          <img src={bgImage} alt="The Last of us" />

          <div className="container itemsDesciprt">
            <h1 className="text-range">Moto G</h1>
            <p className="alert-link mb-2">Next Gen Mobile</p>
            <p>
              The latest Moto X series phone, the Moto X4, has been launched
              exclusively.
            </p>
            <a href="#" className="btn bg-orange text-white alert-link">
              Order Now
            </a>
          </div>
        </div>

        <div className="item">
          <img src={bgImage} alt="GTA V" />
          <div className="container itemsDesciprt">
            <h1 className="text-range">Moto G</h1>
            <p className="alert-link mb-2">Next Gen Mobile</p>
            <p>
              The latest Moto X series phone, the Moto X4, has been launched
              exclusively.
            </p>
            <a href="#" className="btn bg-orange text-white alert-link">
              Order Now
            </a>
          </div>
        </div>

        <div className="item">
          <img src={bgImage} alt="Mirror Edge" />
          <div className="container itemsDesciprt">
            <h1 className="text-range">Moto G</h1>
            <p className="alert-link mb-2">Next Gen Mobile</p>
            <p>
              The latest Moto X series phone, the Moto X4, has been launched
              exclusively.
            </p>
            <a href="#" className="btn bg-orange text-white alert-link">
              Order Now
            </a>
          </div>
        </div>
      </OwlCarousel>
    );
  }
}

export default Carousel;
